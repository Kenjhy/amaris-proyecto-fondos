from mangum import Mangum
from app.main import app
import logging

# Configurar logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Crear manejador para Lambda
handler = Mangum(app, lifespan="off")

# Para debugging
try:
    import sys
    logger.info(f"Python path: {sys.path}")
    logger.info(f"Python version: {sys.version}")
    import pydantic
    logger.info(f"Pydantic version: {pydantic.__version__}")
except Exception as e:
    logger.error(f"Error en importación: {str(e)}")
